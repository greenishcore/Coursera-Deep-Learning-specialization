# Convolutional Neural Networks: Application

Welcome to Course 4's second assignment! In this notebook, you will:

- Create a mood classifer using the TF Keras Sequential API
- Build a ConvNet to identify sign language digits using the TF Keras Functional API

**After this assignment you will be able to:**

- Build and train a ConvNet in TensorFlow for a __binary__ classification problem
- Build and train a ConvNet in TensorFlow for a __multiclass__ classification problem
- Explain different use cases for the Sequential and Functional APIs

To complete this assignment, you should already be familiar with TensorFlow. If you are not, please refer back to the **TensorFlow Tutorial** of the third week of Course 2 ("**Improving deep neural networks**").

## Table of Contents

- [1 - Packages](#1)
    - [1.1 - Load the Data and Split the Data into Train/Test Sets](#1-1)
- [2 - Layers in TF Keras](#2)
- [3 - The Sequential API](#3)
    - [3.1 - Create the Sequential Model](#3-1)
        - [Exercise 1 - happyModel](#ex-1)
    - [3.2 - Train and Evaluate the Model](#3-2)
- [4 - The Functional API](#4)
    - [4.1 - Load the SIGNS Dataset](#4-1)
    - [4.2 - Split the Data into Train/Test Sets](#4-2)
    - [4.3 - Forward Propagation](#4-3)
        - [Exercise 2 - convolutional_model](#ex-2)
    - [4.4 - Train the Model](#4-4)
- [5 - History Object](#5)
- [6 - Bibliography](#6)

<a name='1'></a>
## 1 - Packages

As usual, begin by loading in the packages.


```python
import math
import numpy as np
import h5py
import matplotlib.pyplot as plt
from matplotlib.pyplot import imread
import scipy
from PIL import Image
import pandas as pd
import tensorflow as tf
import tensorflow.keras.layers as tfl
from tensorflow.python.framework import ops
from cnn_utils import *
from test_utils import summary, comparator

%matplotlib inline
np.random.seed(1)
```

<a name='1-1'></a>
### 1.1 - Load the Data and Split the Data into Train/Test Sets

You'll be using the Happy House dataset for this part of the assignment, which contains images of peoples' faces. Your task will be to build a ConvNet that determines whether the people in the images are smiling or not -- because they only get to enter the house if they're smiling!  


```python
X_train_orig, Y_train_orig, X_test_orig, Y_test_orig, classes = load_happy_dataset()

# Normalize image vectors
X_train = X_train_orig/255.
X_test = X_test_orig/255.

# Reshape
Y_train = Y_train_orig.T
Y_test = Y_test_orig.T

print ("number of training examples = " + str(X_train.shape[0]))
print ("number of test examples = " + str(X_test.shape[0]))
print ("X_train shape: " + str(X_train.shape))
print ("Y_train shape: " + str(Y_train.shape))
print ("X_test shape: " + str(X_test.shape))
print ("Y_test shape: " + str(Y_test.shape))
```

    number of training examples = 600
    number of test examples = 150
    X_train shape: (600, 64, 64, 3)
    Y_train shape: (600, 1)
    X_test shape: (150, 64, 64, 3)
    Y_test shape: (150, 1)


You can display the images contained in the dataset. Images are **64x64** pixels in RGB format (3 channels).


```python
index = 124
plt.imshow(X_train_orig[index]) #display sample training image
plt.show()
```


![png](output_7_0.png)


<a name='2'></a>
## 2 - Layers in TF Keras 

In the previous assignment, you created layers manually in numpy. In TF Keras, you don't have to write code directly to create layers. Rather, TF Keras has pre-defined layers you can use. 

When you create a layer in TF Keras, you are creating a function that takes some input and transforms it into an output you can reuse later. Nice and easy! 

<a name='3'></a>
## 3 - The Sequential API

In the previous assignment, you built helper functions using `numpy` to understand the mechanics behind convolutional neural networks. Most practical applications of deep learning today are built using programming frameworks, which have many built-in functions you can simply call. Keras is a high-level abstraction built on top of TensorFlow, which allows for even more simplified and optimized model creation and training. 

For the first part of this assignment, you'll create a model using TF Keras' Sequential API, which allows you to build layer by layer, and is ideal for building models where each layer has **exactly one** input tensor and **one** output tensor. 

As you'll see, using the Sequential API is simple and straightforward, but is only appropriate for simpler, more straightforward tasks. Later in this notebook you'll spend some time building with a more flexible, powerful alternative: the Functional API. 
 

<a name='3-1'></a>
### 3.1 - Create the Sequential Model

As mentioned earlier, the TensorFlow Keras Sequential API can be used to build simple models with layer operations that proceed in a sequential order. 

You can also add layers incrementally to a Sequential model with the `.add()` method, or remove them using the `.pop()` method, much like you would in a regular Python list.

Actually, you can think of a Sequential model as behaving like a list of layers. Like Python lists, Sequential layers are ordered, and the order in which they are specified matters.  If your model is non-linear or contains layers with multiple inputs or outputs, a Sequential model wouldn't be the right choice!

For any layer construction in Keras, you'll need to specify the input shape in advance. This is because in Keras, the shape of the weights is based on the shape of the inputs. The weights are only created when the model first sees some input data. Sequential models can be created by passing a list of layers to the Sequential constructor, like you will do in the next assignment.

<a name='ex-1'></a>
### Exercise 1 - happyModel

Implement the `happyModel` function below to build the following model: `ZEROPAD2D -> CONV2D -> BATCHNORM -> RELU -> MAXPOOL -> FLATTEN -> DENSE`. Take help from [tf.keras.layers](https://www.tensorflow.org/api_docs/python/tf/keras/layers) 

Also, plug in the following parameters for all the steps:

 - [ZeroPadding2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/ZeroPadding2D): padding 3, input shape 64 x 64 x 3
 - [Conv2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Conv2D): Use 32 7x7 filters, stride 1
 - [BatchNormalization](https://www.tensorflow.org/api_docs/python/tf/keras/layers/BatchNormalization): for axis 3
 - [ReLU](https://www.tensorflow.org/api_docs/python/tf/keras/layers/ReLU)
 - [MaxPool2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/MaxPool2D): Using default parameters
 - [Flatten](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Flatten) the previous output.
 - Fully-connected ([Dense](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Dense)) layer: Apply a fully connected layer with 1 neuron and a sigmoid activation. 
 
 
 **Hint:**
 
 Use **tfl** as shorthand for **tensorflow.keras.layers**


```python
# GRADED FUNCTION: happyModel

def happyModel():
    """
    Implements the forward propagation for the binary classification model:
    ZEROPAD2D -> CONV2D -> BATCHNORM -> RELU -> MAXPOOL -> FLATTEN -> DENSE
    
    Note that for simplicity and grading purposes, you'll hard-code all the values
    such as the stride and kernel (filter) sizes. 
    Normally, functions should take these values as function parameters.
    
    Arguments:
    None

    Returns:
    model -- TF Keras model (object containing the information for the entire training process) 
    """
    model = tf.keras.Sequential([
            ## ZeroPadding2D with padding 3, input shape of 64 x 64 x 3
            
            ## Conv2D with 32 7x7 filters and stride of 1
            
            ## BatchNormalization for axis 3
            
            ## ReLU
            
            ## Max Pooling 2D with default parameters
            
            ## Flatten layer
            
            ## Dense layer with 1 unit for output & 'sigmoid' activation
            
            # YOUR CODE STARTS HERE
            tf.keras.layers.ZeroPadding2D(padding=3,input_shape=(64,64,3)),
            tf.keras.layers.Conv2D(32, 7),
            tf.keras.layers.BatchNormalization(axis=3),
            tf.keras.layers.ReLU(),
            tf.keras.layers.MaxPool2D(),
            tf.keras.layers.Flatten(),
            tf.keras.layers.Dense(units=1, activation="sigmoid") 
            # YOUR CODE ENDS HERE
        ])
    
    return model
```


```python
happy_model = happyModel()
# Print a summary for each layer
for layer in summary(happy_model):
    print(layer)
    
output = [['ZeroPadding2D', (None, 70, 70, 3), 0, ((3, 3), (3, 3))],
            ['Conv2D', (None, 64, 64, 32), 4736, 'valid', 'linear', 'GlorotUniform'],
            ['BatchNormalization', (None, 64, 64, 32), 128],
            ['ReLU', (None, 64, 64, 32), 0],
            ['MaxPooling2D', (None, 32, 32, 32), 0, (2, 2), (2, 2), 'valid'],
            ['Flatten', (None, 32768), 0],
            ['Dense', (None, 1), 32769, 'sigmoid']]
    
comparator(summary(happy_model), output)
```

    ['ZeroPadding2D', (None, 70, 70, 3), 0, ((3, 3), (3, 3))]
    ['Conv2D', (None, 64, 64, 32), 4736, 'valid', 'linear', 'GlorotUniform']
    ['BatchNormalization', (None, 64, 64, 32), 128]
    ['ReLU', (None, 64, 64, 32), 0]
    ['MaxPooling2D', (None, 32, 32, 32), 0, (2, 2), (2, 2), 'valid']
    ['Flatten', (None, 32768), 0]
    ['Dense', (None, 1), 32769, 'sigmoid']
    [32mAll tests passed![0m


Now that your model is created, you can compile it for training with an optimizer and loss of your choice. When the string `accuracy` is specified as a metric, the type of accuracy used will be automatically converted based on the loss function used. This is one of the many optimizations built into TensorFlow that make your life easier! If you'd like to read more on how the compiler operates, check the docs [here](https://www.tensorflow.org/api_docs/python/tf/keras/Model#compile).


```python
happy_model.compile(optimizer='adam',
                   loss='binary_crossentropy',
                   metrics=['accuracy'])
```

It's time to check your model's parameters with the `.summary()` method. This will display the types of layers you have, the shape of the outputs, and how many parameters are in each layer. 


```python
happy_model.summary()
```

    Model: "sequential_2"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    zero_padding2d_5 (ZeroPaddin (None, 70, 70, 3)         0         
    _________________________________________________________________
    conv2d_2 (Conv2D)            (None, 64, 64, 32)        4736      
    _________________________________________________________________
    batch_normalization_2 (Batch (None, 64, 64, 32)        128       
    _________________________________________________________________
    re_lu_2 (ReLU)               (None, 64, 64, 32)        0         
    _________________________________________________________________
    max_pooling2d_2 (MaxPooling2 (None, 32, 32, 32)        0         
    _________________________________________________________________
    flatten_2 (Flatten)          (None, 32768)             0         
    _________________________________________________________________
    dense_2 (Dense)              (None, 1)                 32769     
    =================================================================
    Total params: 37,633
    Trainable params: 37,569
    Non-trainable params: 64
    _________________________________________________________________


<a name='3-2'></a>
### 3.2 - Train and Evaluate the Model

After creating the model, compiling it with your choice of optimizer and loss function, and doing a sanity check on its contents, you are now ready to build! 

Simply call `.fit()` to train. That's it! No need for mini-batching, saving, or complex backpropagation computations. That's all been done for you, as you're using a TensorFlow dataset with the batches specified already. You do have the option to specify epoch number or minibatch size if you like (for example, in the case of an un-batched dataset).


```python
happy_model.fit(X_train, Y_train, epochs=10, batch_size=16)
```

    Epoch 1/10
    38/38 [==============================] - 4s 98ms/step - loss: 1.6696 - accuracy: 0.6650
    Epoch 2/10
    38/38 [==============================] - 4s 97ms/step - loss: 0.2370 - accuracy: 0.9067
    Epoch 3/10
    38/38 [==============================] - 4s 95ms/step - loss: 0.2066 - accuracy: 0.9133
    Epoch 4/10
    38/38 [==============================] - 4s 95ms/step - loss: 0.3308 - accuracy: 0.8833
    Epoch 5/10
    38/38 [==============================] - 4s 95ms/step - loss: 0.1139 - accuracy: 0.9583
    Epoch 6/10
    38/38 [==============================] - 4s 95ms/step - loss: 0.1124 - accuracy: 0.9617
    Epoch 7/10
    38/38 [==============================] - 4s 97ms/step - loss: 0.0710 - accuracy: 0.9733
    Epoch 8/10
    38/38 [==============================] - 4s 95ms/step - loss: 0.0996 - accuracy: 0.9700
    Epoch 9/10
    38/38 [==============================] - 4s 95ms/step - loss: 0.0667 - accuracy: 0.9783
    Epoch 10/10
    38/38 [==============================] - 4s 95ms/step - loss: 0.0676 - accuracy: 0.9717





    <tensorflow.python.keras.callbacks.History at 0x7fdf69633050>



After that completes, just use `.evaluate()` to evaluate against your test set. This function will print the value of the loss function and the performance metrics specified during the compilation of the model. In this case, the `binary_crossentropy` and the `accuracy` respectively.


```python
happy_model.evaluate(X_test, Y_test)
```

    5/5 [==============================] - 0s 29ms/step - loss: 0.2763 - accuracy: 0.8733





    [0.27625709772109985, 0.8733333349227905]



Easy, right? But what if you need to build a model with shared layers, branches, or multiple inputs and outputs? This is where Sequential, with its beautifully simple yet limited functionality, won't be able to help you. 

Next up: Enter the Functional API, your slightly more complex, highly flexible friend.  

<a name='4'></a>
## 4 - The Functional API

Welcome to the second half of the assignment, where you'll use Keras' flexible [Functional API](https://www.tensorflow.org/guide/keras/functional) to build a ConvNet that can differentiate between 6 sign language digits. 

The Functional API can handle models with non-linear topology, shared layers, as well as layers with multiple inputs or outputs. Imagine that, where the Sequential API requires the model to move in a linear fashion through its layers, the Functional API allows much more flexibility. Where Sequential is a straight line, a Functional model is a graph, where the nodes of the layers can connect in many more ways than one. 

In the visual example below, the one possible direction of the movement Sequential model is shown in contrast to a skip connection, which is just one of the many ways a Functional model can be constructed. A skip connection, as you might have guessed, skips some layer in the network and feeds the output to a later layer in the network. Don't worry, you'll be spending more time with skip connections very soon! 

<img src="images/seq_vs_func.png" style="width:350px;height:200px;">

<a name='4-1'></a>
### 4.1 - Load the SIGNS Dataset

As a reminder, the SIGNS dataset is a collection of 6 signs representing numbers from 0 to 5.


```python
# Loading the data (signs)
X_train_orig, Y_train_orig, X_test_orig, Y_test_orig, classes = load_signs_dataset()
```

<img src="images/SIGNS.png" style="width:800px;height:300px;">

The next cell will show you an example of a labelled image in the dataset. Feel free to change the value of `index` below and re-run to see different examples. 


```python
# Example of an image from the dataset
index = 9
plt.imshow(X_train_orig[index])
print ("y = " + str(np.squeeze(Y_train_orig[:, index])))
```

    y = 4



![png](output_28_1.png)


<a name='4-2'></a>
### 4.2 - Split the Data into Train/Test Sets

In Course 2, you built a fully-connected network for this dataset. But since this is an image dataset, it is more natural to apply a ConvNet to it.

To get started, let's examine the shapes of your data. 


```python
X_train = X_train_orig/255.
X_test = X_test_orig/255.
Y_train = convert_to_one_hot(Y_train_orig, 6).T
Y_test = convert_to_one_hot(Y_test_orig, 6).T
print ("number of training examples = " + str(X_train.shape[0]))
print ("number of test examples = " + str(X_test.shape[0]))
print ("X_train shape: " + str(X_train.shape))
print ("Y_train shape: " + str(Y_train.shape))
print ("X_test shape: " + str(X_test.shape))
print ("Y_test shape: " + str(Y_test.shape))
```

    number of training examples = 1080
    number of test examples = 120
    X_train shape: (1080, 64, 64, 3)
    Y_train shape: (1080, 6)
    X_test shape: (120, 64, 64, 3)
    Y_test shape: (120, 6)


<a name='4-3'></a>
### 4.3 - Forward Propagation

In TensorFlow, there are built-in functions that implement the convolution steps for you. By now, you should be familiar with how TensorFlow builds computational graphs. In the [Functional API](https://www.tensorflow.org/guide/keras/functional), you create a graph of layers. This is what allows such great flexibility.

However, the following model could also be defined using the Sequential API since the information flow is on a single line. But don't deviate. What we want you to learn is to use the functional API.

Begin building your graph of layers by creating an input node that functions as a callable object:

- **input_img = tf.keras.Input(shape=input_shape):** 

Then, create a new node in the graph of layers by calling a layer on the `input_img` object: 

- **tf.keras.layers.Conv2D(filters= ... , kernel_size= ... , padding='same')(input_img):** Read the full documentation on [Conv2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Conv2D).

- **tf.keras.layers.MaxPool2D(pool_size=(f, f), strides=(s, s), padding='same'):** `MaxPool2D()` downsamples your input using a window of size (f, f) and strides of size (s, s) to carry out max pooling over each window.  For max pooling, you usually operate on a single example at a time and a single channel at a time. Read the full documentation on [MaxPool2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/MaxPool2D).

- **tf.keras.layers.ReLU():** computes the elementwise ReLU of Z (which can be any shape). You can read the full documentation on [ReLU](https://www.tensorflow.org/api_docs/python/tf/keras/layers/ReLU).

- **tf.keras.layers.Flatten()**: given a tensor "P", this function takes each training (or test) example in the batch and flattens it into a 1D vector.  

    * If a tensor P has the shape (batch_size,h,w,c), it returns a flattened tensor with shape (batch_size, k), where $k=h \times w \times c$.  "k" equals the product of all the dimension sizes other than the first dimension.
    
    * For example, given a tensor with dimensions [100, 2, 3, 4], it flattens the tensor to be of shape [100, 24], where 24 = 2 * 3 * 4.  You can read the full documentation on [Flatten](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Flatten).

- **tf.keras.layers.Dense(units= ... , activation='softmax')(F):** given the flattened input F, it returns the output computed using a fully connected layer. You can read the full documentation on [Dense](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Dense).

In the last function above (`tf.keras.layers.Dense()`), the fully connected layer automatically initializes weights in the graph and keeps on training them as you train the model. Hence, you did not need to initialize those weights when initializing the parameters.

Lastly, before creating the model, you'll need to define the output using the last of the function's compositions (in this example, a Dense layer): 

- **outputs = tf.keras.layers.Dense(units=6, activation='softmax')(F)**


#### Window, kernel, filter, pool

The words "kernel" and "filter" are used to refer to the same thing. The word "filter" accounts for the amount of "kernels" that will be used in a single convolution layer. "Pool" is the name of the operation that takes the max or average value of the kernels. 

This is why the parameter `pool_size` refers to `kernel_size`, and you use `(f,f)` to refer to the filter size. 

Pool size and kernel size refer to the same thing in different objects - They refer to the shape of the window where the operation takes place. 

<a name='ex-2'></a>
### Exercise 2 - convolutional_model

Implement the `convolutional_model` function below to build the following model: `CONV2D -> RELU -> MAXPOOL -> CONV2D -> RELU -> MAXPOOL -> FLATTEN -> DENSE`. Use the functions above! 

Also, plug in the following parameters for all the steps:

 - [Conv2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Conv2D): Use 8 4 by 4 filters, stride 1, padding is "SAME"
 - [ReLU](https://www.tensorflow.org/api_docs/python/tf/keras/layers/ReLU)
 - [MaxPool2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/MaxPool2D): Use an 8 by 8 filter size and an 8 by 8 stride, padding is "SAME"
 - **Conv2D**: Use 16 2 by 2 filters, stride 1, padding is "SAME"
 - **ReLU**
 - **MaxPool2D**: Use a 4 by 4 filter size and a 4 by 4 stride, padding is "SAME"
 - [Flatten](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Flatten) the previous output.
 - Fully-connected ([Dense](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Dense)) layer: Apply a fully connected layer with 6 neurons and a softmax activation. 


```python
# GRADED FUNCTION: convolutional_model

def convolutional_model(input_shape):
    """
    Implements the forward propagation for the model:
    CONV2D -> RELU -> MAXPOOL -> CONV2D -> RELU -> MAXPOOL -> FLATTEN -> DENSE
    
    Note that for simplicity and grading purposes, you'll hard-code some values
    such as the stride and kernel (filter) sizes. 
    Normally, functions should take these values as function parameters.
    
    Arguments:
    input_img -- input dataset, of shape (input_shape)

    Returns:
    model -- TF Keras model (object containing the information for the entire training process) 
    """

    input_img = tf.keras.Input(shape=input_shape)
    ## CONV2D: 8 filters 4x4, stride of 1, padding 'SAME'
    # Z1 = None
    ## RELU
    # A1 = None
    ## MAXPOOL: window 8x8, stride 8, padding 'SAME'
    # P1 = None
    ## CONV2D: 16 filters 2x2, stride 1, padding 'SAME'
    # Z2 = None
    ## RELU
    # A2 = None
    ## MAXPOOL: window 4x4, stride 4, padding 'SAME'
    # P2 = None
    ## FLATTEN
    # F = None
    ## Dense layer
    ## 6 neurons in output layer. Hint: one of the arguments should be "activation='softmax'" 
    # outputs = None
    # YOUR CODE STARTS HERE
    Z1 = tfl.Conv2D(8, (4,4), strides = (1,1), padding='SAME')(input_img)
    A1 = tfl.ReLU()(Z1)
    P1 = tf.keras.layers.MaxPool2D(pool_size=(8, 8), strides = (8, 8), padding = 'SAME')(A1)
    Z2 = tfl.Conv2D(16, (2, 2), strides = (1, 1), padding = 'SAME')(P1)
    A2 = tfl.ReLU()(Z2)
    P2 = tfl.MaxPool2D(pool_size=(4,4), strides = (4, 4), padding = 'SAME')(A2)
    F = tf.keras.layers.Flatten()(P2)
    outputs = tf.keras.layers.Dense(6, activation='softmax')(F)
    # YOUR CODE ENDS HERE
    model = tf.keras.Model(inputs=input_img, outputs=outputs)
    return model
```


```python
conv_model = convolutional_model((64, 64, 3))
conv_model.compile(optimizer='adam',
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])
conv_model.summary()
    
output = [['InputLayer', [(None, 64, 64, 3)], 0],
        ['Conv2D', (None, 64, 64, 8), 392, 'same', 'linear', 'GlorotUniform'],
        ['ReLU', (None, 64, 64, 8), 0],
        ['MaxPooling2D', (None, 8, 8, 8), 0, (8, 8), (8, 8), 'same'],
        ['Conv2D', (None, 8, 8, 16), 528, 'same', 'linear', 'GlorotUniform'],
        ['ReLU', (None, 8, 8, 16), 0],
        ['MaxPooling2D', (None, 2, 2, 16), 0, (4, 4), (4, 4), 'same'],
        ['Flatten', (None, 64), 0],
        ['Dense', (None, 6), 390, 'softmax']]
    
comparator(summary(conv_model), output)
```

    Model: "functional_4"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    input_4 (InputLayer)         [(None, 64, 64, 3)]       0         
    _________________________________________________________________
    conv2d_9 (Conv2D)            (None, 64, 64, 8)         392       
    _________________________________________________________________
    re_lu_9 (ReLU)               (None, 64, 64, 8)         0         
    _________________________________________________________________
    max_pooling2d_9 (MaxPooling2 (None, 8, 8, 8)           0         
    _________________________________________________________________
    conv2d_10 (Conv2D)           (None, 8, 8, 16)          528       
    _________________________________________________________________
    re_lu_10 (ReLU)              (None, 8, 8, 16)          0         
    _________________________________________________________________
    max_pooling2d_10 (MaxPooling (None, 2, 2, 16)          0         
    _________________________________________________________________
    flatten_6 (Flatten)          (None, 64)                0         
    _________________________________________________________________
    dense_6 (Dense)              (None, 6)                 390       
    =================================================================
    Total params: 1,310
    Trainable params: 1,310
    Non-trainable params: 0
    _________________________________________________________________
    [32mAll tests passed![0m


Both the Sequential and Functional APIs return a TF Keras model object. The only difference is how inputs are handled inside the object model! 

<a name='4-4'></a>
### 4.4 - Train the Model


```python
train_dataset = tf.data.Dataset.from_tensor_slices((X_train, Y_train)).batch(64)
test_dataset = tf.data.Dataset.from_tensor_slices((X_test, Y_test)).batch(64)
history = conv_model.fit(train_dataset, epochs=100, validation_data=test_dataset)
```

    Epoch 1/100
    17/17 [==============================] - 2s 112ms/step - loss: 1.8042 - accuracy: 0.1833 - val_loss: 1.7922 - val_accuracy: 0.2250
    Epoch 2/100
    17/17 [==============================] - 2s 112ms/step - loss: 1.7896 - accuracy: 0.2185 - val_loss: 1.7878 - val_accuracy: 0.2583
    Epoch 3/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7849 - accuracy: 0.2407 - val_loss: 1.7835 - val_accuracy: 0.2500
    Epoch 4/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7807 - accuracy: 0.2843 - val_loss: 1.7785 - val_accuracy: 0.2750
    Epoch 5/100
    17/17 [==============================] - 2s 111ms/step - loss: 1.7757 - accuracy: 0.3120 - val_loss: 1.7729 - val_accuracy: 0.3583
    Epoch 6/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7699 - accuracy: 0.3509 - val_loss: 1.7647 - val_accuracy: 0.3667
    Epoch 7/100
    17/17 [==============================] - 2s 107ms/step - loss: 1.7606 - accuracy: 0.3898 - val_loss: 1.7539 - val_accuracy: 0.3917
    Epoch 8/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7481 - accuracy: 0.4157 - val_loss: 1.7393 - val_accuracy: 0.4333
    Epoch 9/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7315 - accuracy: 0.4472 - val_loss: 1.7196 - val_accuracy: 0.4250
    Epoch 10/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7088 - accuracy: 0.4398 - val_loss: 1.6941 - val_accuracy: 0.4167
    Epoch 11/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.6792 - accuracy: 0.4435 - val_loss: 1.6609 - val_accuracy: 0.4250
    Epoch 12/100
    17/17 [==============================] - 2s 111ms/step - loss: 1.6398 - accuracy: 0.4509 - val_loss: 1.6220 - val_accuracy: 0.4500
    Epoch 13/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.5935 - accuracy: 0.4556 - val_loss: 1.5763 - val_accuracy: 0.4583
    Epoch 14/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.5420 - accuracy: 0.4759 - val_loss: 1.5321 - val_accuracy: 0.5083
    Epoch 15/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.4875 - accuracy: 0.4944 - val_loss: 1.4814 - val_accuracy: 0.4917
    Epoch 16/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.4339 - accuracy: 0.5102 - val_loss: 1.4333 - val_accuracy: 0.4750
    Epoch 17/100
    17/17 [==============================] - 2s 107ms/step - loss: 1.3815 - accuracy: 0.5296 - val_loss: 1.3855 - val_accuracy: 0.4917
    Epoch 18/100
    17/17 [==============================] - 2s 107ms/step - loss: 1.3316 - accuracy: 0.5509 - val_loss: 1.3382 - val_accuracy: 0.5333
    Epoch 19/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.2839 - accuracy: 0.5722 - val_loss: 1.2924 - val_accuracy: 0.5500
    Epoch 20/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.2374 - accuracy: 0.5991 - val_loss: 1.2495 - val_accuracy: 0.5500
    Epoch 21/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.1930 - accuracy: 0.6324 - val_loss: 1.2074 - val_accuracy: 0.5583
    Epoch 22/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.1494 - accuracy: 0.6500 - val_loss: 1.1654 - val_accuracy: 0.6000
    Epoch 23/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.1074 - accuracy: 0.6602 - val_loss: 1.1258 - val_accuracy: 0.6167
    Epoch 24/100
    17/17 [==============================] - 2s 107ms/step - loss: 1.0669 - accuracy: 0.6704 - val_loss: 1.0896 - val_accuracy: 0.6333
    Epoch 25/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.0264 - accuracy: 0.6843 - val_loss: 1.0537 - val_accuracy: 0.6500
    Epoch 26/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.9871 - accuracy: 0.6991 - val_loss: 1.0181 - val_accuracy: 0.6500
    Epoch 27/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.9511 - accuracy: 0.7176 - val_loss: 0.9856 - val_accuracy: 0.6583
    Epoch 28/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.9152 - accuracy: 0.7204 - val_loss: 0.9513 - val_accuracy: 0.6667
    Epoch 29/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.8828 - accuracy: 0.7250 - val_loss: 0.9167 - val_accuracy: 0.6667
    Epoch 30/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.8522 - accuracy: 0.7380 - val_loss: 0.8877 - val_accuracy: 0.7000
    Epoch 31/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.8228 - accuracy: 0.7454 - val_loss: 0.8594 - val_accuracy: 0.7083
    Epoch 32/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.7943 - accuracy: 0.7500 - val_loss: 0.8325 - val_accuracy: 0.7167
    Epoch 33/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.7686 - accuracy: 0.7528 - val_loss: 0.8072 - val_accuracy: 0.7333
    Epoch 34/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.7459 - accuracy: 0.7648 - val_loss: 0.7846 - val_accuracy: 0.7583
    Epoch 35/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.7246 - accuracy: 0.7685 - val_loss: 0.7644 - val_accuracy: 0.7750
    Epoch 36/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.7042 - accuracy: 0.7769 - val_loss: 0.7452 - val_accuracy: 0.7750
    Epoch 37/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6861 - accuracy: 0.7852 - val_loss: 0.7275 - val_accuracy: 0.7750
    Epoch 38/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6679 - accuracy: 0.7926 - val_loss: 0.7118 - val_accuracy: 0.7917
    Epoch 39/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6513 - accuracy: 0.7944 - val_loss: 0.6963 - val_accuracy: 0.7917
    Epoch 40/100
    17/17 [==============================] - 2s 112ms/step - loss: 0.6360 - accuracy: 0.8028 - val_loss: 0.6819 - val_accuracy: 0.8083
    Epoch 41/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.6212 - accuracy: 0.8093 - val_loss: 0.6690 - val_accuracy: 0.8000
    Epoch 42/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.6066 - accuracy: 0.8157 - val_loss: 0.6582 - val_accuracy: 0.8083
    Epoch 43/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5937 - accuracy: 0.8185 - val_loss: 0.6469 - val_accuracy: 0.8083
    Epoch 44/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5813 - accuracy: 0.8241 - val_loss: 0.6368 - val_accuracy: 0.8083
    Epoch 45/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5689 - accuracy: 0.8269 - val_loss: 0.6265 - val_accuracy: 0.8083
    Epoch 46/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.5575 - accuracy: 0.8315 - val_loss: 0.6177 - val_accuracy: 0.8083
    Epoch 47/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5468 - accuracy: 0.8361 - val_loss: 0.6088 - val_accuracy: 0.8083
    Epoch 48/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5364 - accuracy: 0.8389 - val_loss: 0.6007 - val_accuracy: 0.8083
    Epoch 49/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.5265 - accuracy: 0.8454 - val_loss: 0.5926 - val_accuracy: 0.8083
    Epoch 50/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.5164 - accuracy: 0.8463 - val_loss: 0.5855 - val_accuracy: 0.8083
    Epoch 51/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5071 - accuracy: 0.8481 - val_loss: 0.5777 - val_accuracy: 0.8083
    Epoch 52/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4983 - accuracy: 0.8519 - val_loss: 0.5707 - val_accuracy: 0.8083
    Epoch 53/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.4896 - accuracy: 0.8537 - val_loss: 0.5636 - val_accuracy: 0.8083
    Epoch 54/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4813 - accuracy: 0.8537 - val_loss: 0.5574 - val_accuracy: 0.8167
    Epoch 55/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4735 - accuracy: 0.8565 - val_loss: 0.5508 - val_accuracy: 0.8167
    Epoch 56/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.4658 - accuracy: 0.8611 - val_loss: 0.5449 - val_accuracy: 0.8167
    Epoch 57/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4583 - accuracy: 0.8620 - val_loss: 0.5391 - val_accuracy: 0.8167
    Epoch 58/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4511 - accuracy: 0.8639 - val_loss: 0.5336 - val_accuracy: 0.8167
    Epoch 59/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4440 - accuracy: 0.8667 - val_loss: 0.5280 - val_accuracy: 0.8167
    Epoch 60/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4371 - accuracy: 0.8685 - val_loss: 0.5231 - val_accuracy: 0.8250
    Epoch 61/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4303 - accuracy: 0.8685 - val_loss: 0.5180 - val_accuracy: 0.8250
    Epoch 62/100
    17/17 [==============================] - 2s 112ms/step - loss: 0.4239 - accuracy: 0.8685 - val_loss: 0.5130 - val_accuracy: 0.8500
    Epoch 63/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.4177 - accuracy: 0.8722 - val_loss: 0.5082 - val_accuracy: 0.8583
    Epoch 64/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4116 - accuracy: 0.8759 - val_loss: 0.5039 - val_accuracy: 0.8667
    Epoch 65/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.4059 - accuracy: 0.8769 - val_loss: 0.4997 - val_accuracy: 0.8667
    Epoch 66/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4000 - accuracy: 0.8806 - val_loss: 0.4957 - val_accuracy: 0.8583
    Epoch 67/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.3945 - accuracy: 0.8815 - val_loss: 0.4912 - val_accuracy: 0.8583
    Epoch 68/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.3888 - accuracy: 0.8824 - val_loss: 0.4880 - val_accuracy: 0.8667
    Epoch 69/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.3835 - accuracy: 0.8843 - val_loss: 0.4836 - val_accuracy: 0.8583
    Epoch 70/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.3784 - accuracy: 0.8870 - val_loss: 0.4801 - val_accuracy: 0.8583
    Epoch 71/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.3733 - accuracy: 0.8898 - val_loss: 0.4767 - val_accuracy: 0.8583
    Epoch 72/100
    17/17 [==============================] - 2s 112ms/step - loss: 0.3685 - accuracy: 0.8898 - val_loss: 0.4736 - val_accuracy: 0.8583
    Epoch 73/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.3638 - accuracy: 0.8917 - val_loss: 0.4703 - val_accuracy: 0.8583
    Epoch 74/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.3591 - accuracy: 0.8917 - val_loss: 0.4672 - val_accuracy: 0.8500
    Epoch 75/100
    17/17 [==============================] - 2s 101ms/step - loss: 0.3546 - accuracy: 0.8926 - val_loss: 0.4641 - val_accuracy: 0.8583
    Epoch 76/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.3502 - accuracy: 0.8963 - val_loss: 0.4603 - val_accuracy: 0.8583
    Epoch 77/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.3456 - accuracy: 0.9019 - val_loss: 0.4579 - val_accuracy: 0.8583
    Epoch 78/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.3416 - accuracy: 0.9028 - val_loss: 0.4544 - val_accuracy: 0.8583
    Epoch 79/100
    17/17 [==============================] - 2s 112ms/step - loss: 0.3376 - accuracy: 0.9028 - val_loss: 0.4515 - val_accuracy: 0.8583
    Epoch 80/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.3334 - accuracy: 0.9083 - val_loss: 0.4485 - val_accuracy: 0.8583
    Epoch 81/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.3295 - accuracy: 0.9083 - val_loss: 0.4454 - val_accuracy: 0.8583
    Epoch 82/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.3257 - accuracy: 0.9093 - val_loss: 0.4427 - val_accuracy: 0.8583
    Epoch 83/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.3221 - accuracy: 0.9093 - val_loss: 0.4399 - val_accuracy: 0.8583
    Epoch 84/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.3183 - accuracy: 0.9111 - val_loss: 0.4374 - val_accuracy: 0.8583
    Epoch 85/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.3146 - accuracy: 0.9130 - val_loss: 0.4342 - val_accuracy: 0.8583
    Epoch 86/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.3110 - accuracy: 0.9139 - val_loss: 0.4319 - val_accuracy: 0.8583
    Epoch 87/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.3076 - accuracy: 0.9148 - val_loss: 0.4294 - val_accuracy: 0.8667
    Epoch 88/100
    17/17 [==============================] - 2s 112ms/step - loss: 0.3044 - accuracy: 0.9157 - val_loss: 0.4277 - val_accuracy: 0.8667
    Epoch 89/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.3012 - accuracy: 0.9167 - val_loss: 0.4256 - val_accuracy: 0.8667
    Epoch 90/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.2980 - accuracy: 0.9176 - val_loss: 0.4235 - val_accuracy: 0.8667
    Epoch 91/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.2950 - accuracy: 0.9194 - val_loss: 0.4208 - val_accuracy: 0.8667
    Epoch 92/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.2917 - accuracy: 0.9204 - val_loss: 0.4195 - val_accuracy: 0.8667
    Epoch 93/100
    17/17 [==============================] - 2s 112ms/step - loss: 0.2888 - accuracy: 0.9194 - val_loss: 0.4176 - val_accuracy: 0.8667
    Epoch 94/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.2858 - accuracy: 0.9194 - val_loss: 0.4157 - val_accuracy: 0.8750
    Epoch 95/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.2825 - accuracy: 0.9213 - val_loss: 0.4143 - val_accuracy: 0.8667
    Epoch 96/100
    17/17 [==============================] - 2s 112ms/step - loss: 0.2795 - accuracy: 0.9231 - val_loss: 0.4121 - val_accuracy: 0.8583
    Epoch 97/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.2765 - accuracy: 0.9222 - val_loss: 0.4103 - val_accuracy: 0.8667
    Epoch 98/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.2738 - accuracy: 0.9250 - val_loss: 0.4078 - val_accuracy: 0.8667
    Epoch 99/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.2708 - accuracy: 0.9287 - val_loss: 0.4067 - val_accuracy: 0.8667
    Epoch 100/100
    17/17 [==============================] - 2s 112ms/step - loss: 0.2683 - accuracy: 0.9278 - val_loss: 0.4047 - val_accuracy: 0.8667


<a name='5'></a>
## 5 - History Object 

The history object is an output of the `.fit()` operation, and provides a record of all the loss and metric values in memory. It's stored as a dictionary that you can retrieve at `history.history`: 


```python
history.history
```




    {'loss': [1.8041552305221558,
      1.7896454334259033,
      1.7848774194717407,
      1.7807368040084839,
      1.7756987810134888,
      1.7699183225631714,
      1.7605973482131958,
      1.7481414079666138,
      1.7314788103103638,
      1.7087923288345337,
      1.6791881322860718,
      1.6397818326950073,
      1.5935149192810059,
      1.542037844657898,
      1.4875036478042603,
      1.4338799715042114,
      1.381514072418213,
      1.3316481113433838,
      1.283934473991394,
      1.2373684644699097,
      1.1930285692214966,
      1.1493624448776245,
      1.107367753982544,
      1.0668656826019287,
      1.0263645648956299,
      0.98707515001297,
      0.9511180520057678,
      0.9152289628982544,
      0.8828418850898743,
      0.8521673679351807,
      0.8227773308753967,
      0.7942728996276855,
      0.7685619592666626,
      0.7458795309066772,
      0.724552571773529,
      0.7041841745376587,
      0.6860663294792175,
      0.6678600907325745,
      0.6512721180915833,
      0.6359713673591614,
      0.6211709976196289,
      0.6066418886184692,
      0.5936890840530396,
      0.5813053250312805,
      0.5689325928688049,
      0.5575200319290161,
      0.5467837452888489,
      0.5364326238632202,
      0.5264546275138855,
      0.5163646340370178,
      0.5071454048156738,
      0.49831724166870117,
      0.489645779132843,
      0.481302946805954,
      0.4735391438007355,
      0.465807169675827,
      0.45830532908439636,
      0.45112165808677673,
      0.4439927637577057,
      0.43710625171661377,
      0.4303100109100342,
      0.4239179790019989,
      0.41766199469566345,
      0.41158631443977356,
      0.40590131282806396,
      0.39996597170829773,
      0.3945104479789734,
      0.38878387212753296,
      0.38354119658470154,
      0.3784148693084717,
      0.37327250838279724,
      0.3685232102870941,
      0.3637508749961853,
      0.35908588767051697,
      0.35464319586753845,
      0.3501637876033783,
      0.3456306457519531,
      0.3415929079055786,
      0.33756306767463684,
      0.3333701193332672,
      0.32953885197639465,
      0.3256959021091461,
      0.32205870747566223,
      0.3183482885360718,
      0.31458133459091187,
      0.31100994348526,
      0.3076256215572357,
      0.30436354875564575,
      0.30115175247192383,
      0.29798391461372375,
      0.29503169655799866,
      0.29174551367759705,
      0.2888439893722534,
      0.2857871949672699,
      0.28254884481430054,
      0.2794809639453888,
      0.2764521837234497,
      0.27375349402427673,
      0.2708440124988556,
      0.2683046758174896],
     'accuracy': [0.18333333730697632,
      0.21851852536201477,
      0.24074074625968933,
      0.28425925970077515,
      0.31203705072402954,
      0.35092592239379883,
      0.3898148238658905,
      0.4157407283782959,
      0.4472222328186035,
      0.43981480598449707,
      0.4435185194015503,
      0.45092591643333435,
      0.4555555582046509,
      0.47592592239379883,
      0.49444442987442017,
      0.510185182094574,
      0.529629647731781,
      0.5509259104728699,
      0.5722222328186035,
      0.5990740656852722,
      0.6324074268341064,
      0.6499999761581421,
      0.6601851582527161,
      0.6703703999519348,
      0.6842592358589172,
      0.6990740895271301,
      0.7175925970077515,
      0.720370352268219,
      0.7250000238418579,
      0.7379629611968994,
      0.7453703880310059,
      0.75,
      0.7527777552604675,
      0.7648147940635681,
      0.7685185074806213,
      0.7768518328666687,
      0.7851851582527161,
      0.7925925850868225,
      0.7944444417953491,
      0.8027777671813965,
      0.8092592358589172,
      0.8157407641410828,
      0.8185185194015503,
      0.8240740895271301,
      0.8268518447875977,
      0.8314814567565918,
      0.8361111283302307,
      0.8388888835906982,
      0.845370352268219,
      0.8462963104248047,
      0.8481481671333313,
      0.8518518805503845,
      0.8537036776542664,
      0.8537036776542664,
      0.8564814925193787,
      0.8611111044883728,
      0.8620370626449585,
      0.8638888597488403,
      0.8666666746139526,
      0.8685185313224792,
      0.8685185313224792,
      0.8685185313224792,
      0.8722222447395325,
      0.8759258985519409,
      0.8768518567085266,
      0.8805555701255798,
      0.8814814686775208,
      0.8824074268341064,
      0.8842592835426331,
      0.8870370388031006,
      0.8898147940635681,
      0.8898147940635681,
      0.8916666507720947,
      0.8916666507720947,
      0.8925926089286804,
      0.8962963223457336,
      0.9018518328666687,
      0.9027777910232544,
      0.9027777910232544,
      0.9083333611488342,
      0.9083333611488342,
      0.9092592597007751,
      0.9092592597007751,
      0.9111111164093018,
      0.9129629731178284,
      0.9138888716697693,
      0.914814829826355,
      0.9157407283782959,
      0.9166666865348816,
      0.9175925850868225,
      0.9194444417953491,
      0.9203703999519348,
      0.9194444417953491,
      0.9194444417953491,
      0.9212962985038757,
      0.9231481552124023,
      0.9222221970558167,
      0.925000011920929,
      0.9287037253379822,
      0.9277777671813965],
     'val_loss': [1.7921665906906128,
      1.7878410816192627,
      1.7835489511489868,
      1.778534173965454,
      1.7728760242462158,
      1.7647318840026855,
      1.7538951635360718,
      1.739345669746399,
      1.719580054283142,
      1.6940810680389404,
      1.6609395742416382,
      1.6219897270202637,
      1.5763309001922607,
      1.5320571660995483,
      1.4814146757125854,
      1.4333382844924927,
      1.3855303525924683,
      1.3381812572479248,
      1.2923815250396729,
      1.249484658241272,
      1.2074254751205444,
      1.165351390838623,
      1.1257917881011963,
      1.089643120765686,
      1.0537041425704956,
      1.0181373357772827,
      0.9855933785438538,
      0.9512941837310791,
      0.9166600704193115,
      0.8877245783805847,
      0.8593534827232361,
      0.8325017094612122,
      0.8072456121444702,
      0.784600555896759,
      0.7644136548042297,
      0.7452498078346252,
      0.7275003790855408,
      0.711804211139679,
      0.6963487267494202,
      0.6819286346435547,
      0.6690306067466736,
      0.6581847071647644,
      0.6468850374221802,
      0.6367999911308289,
      0.6264848113059998,
      0.6176618933677673,
      0.6087692379951477,
      0.6007104516029358,
      0.5925747156143188,
      0.5854624509811401,
      0.5777314305305481,
      0.5707434415817261,
      0.5636098384857178,
      0.5574446320533752,
      0.5507887005805969,
      0.5449107885360718,
      0.5391078591346741,
      0.533568799495697,
      0.5280113816261292,
      0.5230716466903687,
      0.5180179476737976,
      0.5130383968353271,
      0.5081949830055237,
      0.5039148926734924,
      0.4997219443321228,
      0.4956778287887573,
      0.4912107586860657,
      0.48795121908187866,
      0.4836316704750061,
      0.4801141321659088,
      0.47674280405044556,
      0.4736103117465973,
      0.47031861543655396,
      0.46721789240837097,
      0.46405819058418274,
      0.4603336453437805,
      0.4579470455646515,
      0.4544391632080078,
      0.4514879286289215,
      0.448520690202713,
      0.44542598724365234,
      0.4426557421684265,
      0.43985065817832947,
      0.4374268352985382,
      0.4342053234577179,
      0.43187862634658813,
      0.4294145703315735,
      0.42769914865493774,
      0.4255649447441101,
      0.4234670102596283,
      0.4208349287509918,
      0.4194573760032654,
      0.4175640344619751,
      0.4157300293445587,
      0.41428324580192566,
      0.41205310821533203,
      0.4103454649448395,
      0.4078451693058014,
      0.4066762328147888,
      0.40466251969337463],
     'val_accuracy': [0.22499999403953552,
      0.25833332538604736,
      0.25,
      0.2750000059604645,
      0.3583333194255829,
      0.36666667461395264,
      0.3916666805744171,
      0.4333333373069763,
      0.42500001192092896,
      0.4166666567325592,
      0.42500001192092896,
      0.44999998807907104,
      0.4583333432674408,
      0.5083333253860474,
      0.49166667461395264,
      0.4749999940395355,
      0.49166667461395264,
      0.5333333611488342,
      0.550000011920929,
      0.550000011920929,
      0.5583333373069763,
      0.6000000238418579,
      0.6166666746139526,
      0.6333333253860474,
      0.6499999761581421,
      0.6499999761581421,
      0.6583333611488342,
      0.6666666865348816,
      0.6666666865348816,
      0.699999988079071,
      0.7083333134651184,
      0.7166666388511658,
      0.7333333492279053,
      0.7583333253860474,
      0.7749999761581421,
      0.7749999761581421,
      0.7749999761581421,
      0.7916666865348816,
      0.7916666865348816,
      0.8083333373069763,
      0.800000011920929,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.8166666626930237,
      0.8166666626930237,
      0.8166666626930237,
      0.8166666626930237,
      0.8166666626930237,
      0.8166666626930237,
      0.824999988079071,
      0.824999988079071,
      0.8500000238418579,
      0.8583333492279053,
      0.8666666746139526,
      0.8666666746139526,
      0.8583333492279053,
      0.8583333492279053,
      0.8666666746139526,
      0.8583333492279053,
      0.8583333492279053,
      0.8583333492279053,
      0.8583333492279053,
      0.8583333492279053,
      0.8500000238418579,
      0.8583333492279053,
      0.8583333492279053,
      0.8583333492279053,
      0.8583333492279053,
      0.8583333492279053,
      0.8583333492279053,
      0.8583333492279053,
      0.8583333492279053,
      0.8583333492279053,
      0.8583333492279053,
      0.8583333492279053,
      0.8583333492279053,
      0.8666666746139526,
      0.8666666746139526,
      0.8666666746139526,
      0.8666666746139526,
      0.8666666746139526,
      0.8666666746139526,
      0.8666666746139526,
      0.875,
      0.8666666746139526,
      0.8583333492279053,
      0.8666666746139526,
      0.8666666746139526,
      0.8666666746139526,
      0.8666666746139526]}



Now visualize the loss over time using `history.history`: 


```python
# The history.history["loss"] entry is a dictionary with as many values as epochs that the
# model was trained on. 
df_loss_acc = pd.DataFrame(history.history)
df_loss= df_loss_acc[['loss','val_loss']]
df_loss.rename(columns={'loss':'train','val_loss':'validation'},inplace=True)
df_acc= df_loss_acc[['accuracy','val_accuracy']]
df_acc.rename(columns={'accuracy':'train','val_accuracy':'validation'},inplace=True)
df_loss.plot(title='Model loss',figsize=(12,8)).set(xlabel='Epoch',ylabel='Loss')
df_acc.plot(title='Model Accuracy',figsize=(12,8)).set(xlabel='Epoch',ylabel='Accuracy')
```




    [Text(0, 0.5, 'Accuracy'), Text(0.5, 0, 'Epoch')]




![png](output_41_1.png)



![png](output_41_2.png)


**Congratulations**! You've finished the assignment and built two models: One that recognizes  smiles, and another that recognizes SIGN language with almost 80% accuracy on the test set. In addition to that, you now also understand the applications of two Keras APIs: Sequential and Functional. Nicely done! 

By now, you know a bit about how the Functional API works and may have glimpsed the possibilities. In your next assignment, you'll really get a feel for its power when you get the opportunity to build a very deep ConvNet, using ResNets! 

<a name='6'></a>
## 6 - Bibliography

You're always encouraged to read the official documentation. To that end, you can find the docs for the Sequential and Functional APIs here: 

https://www.tensorflow.org/guide/keras/sequential_model

https://www.tensorflow.org/guide/keras/functional
